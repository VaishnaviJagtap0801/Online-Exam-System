package com.linkcode.online.exams;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineExamsApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineExamsApplication.class, args);
	}

}

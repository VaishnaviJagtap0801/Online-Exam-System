package com.linkcode.online.exams.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.linkcode.online.exams.entity.Student;
import com.linkcode.online.exams.entity.Answer;
import com.linkcode.online.exams.entity.Questions;
import java.util.*;
@Controller
public class LoginController {
	@Autowired
	
	SessionFactory factory;

	// localhost:8080/login
	@RequestMapping("login")
	public String login()
	{
		return "login";  // here login is jsp page name
	}
	
	@RequestMapping("register")
    public String registerPage() {
        return "register";  // here register is the JSP page name
    }
	
	@RequestMapping("Admin")
    public String questionmanagement() {
        return "questionmanagement";  // here register is the JSP page name
    }
	
	@RequestMapping("register2")
    public ModelAndView register(String username, String password, long mobno,String emailid, String imagepath, HttpServletRequest request) {
        ModelAndView modelAndView = new ModelAndView();

        // Check if the username already exists
        Session session = factory.openSession();
        Student userFromDb = session.get(Student.class, username);

        if (userFromDb != null) {
            modelAndView.setViewName("register");
            modelAndView.addObject("message", "Username already exists. Choose a different one.");
        } 
        else {
            // Create a new user
            Student newUser = new Student(username, password, mobno, emailid, imagepath);
            session.beginTransaction();
            session.save(newUser);
            session.getTransaction().commit();

            modelAndView.setViewName("login");
            modelAndView.addObject("message", "Registration successful. You can now log in.");
        }

        return modelAndView;
    }
	
	
	@RequestMapping("validate")
	public ModelAndView validate(String username,String password,HttpServletRequest request)
	{
		ModelAndView modelandview=new ModelAndView();
		
		Session session=factory.openSession();

		Student userfromdb=session.get(Student.class,username);
			
		if(userfromdb==null)
		{
			modelandview.setViewName("login"); // view page name means JSP page name
			modelandview.addObject("message","wrong username or password"); // here message attribute represents data which will be displayed on view page . here message is called model attribute
			
		}
		
		else if(userfromdb.password.equals(password))
		{
			modelandview.setViewName("welcome"); // view page name means JSP page name
			
			HttpSession httpsession=request.getSession();
			
			httpsession.setAttribute("username",username);
			
		}
		
		else
		{
			modelandview.setViewName("login"); // view page name means JSP page name
			modelandview.addObject("message","wrong password"); // here message attribute represents data which will be displayed on view page . here message is called model attribute
		}
		
		return modelandview;
	
	}
	
	@RequestMapping("startExam")
	public ModelAndView startExam(String selectedSubject,HttpServletRequest request) {
		
		System.out.println(selectedSubject);
		ModelAndView modelandview=new ModelAndView();
		if(selectedSubject==null)
		{
			modelandview.setViewName("login");
		}
		else
		{
			Session session=factory.openSession();
			/* Criteria is for only fetcing record(select query)
			 * HQL is for all operations (insert update delete select)
			 * 
			 */
		
			//using add() we add condiotion,based on which records are fetched from database
			//e.g. we want only those record which are having value maths for subject column (assume selectedSubject is maths)
			//select * from questions where subject="maths"
			//List klistOfQuestions=session.createCriteria(Questions.class).add(Restrictions.eq("subject",selectedSubject).list();
		
			HttpSession httpsession=request.getSession();
			httpsession.setAttribute("qno",0);
			httpsession.setAttribute("timeremaining",121);
			
			
			
			Query<Questions> query = session.createQuery("from Questions where subject=:subject order by DBMS_RANDOM.VALUE()", Questions.class);
			query.setParameter("subject", selectedSubject);
			List<Questions> listOfQuestions = query.list();

			
			modelandview.setViewName("questions");
			modelandview.addObject("listOfQuestions",listOfQuestions);
			modelandview.addObject("question",listOfQuestions.get(0));
			httpsession.setAttribute("allquestions",listOfQuestions);
			
			HashMap<Integer,Answer> hashmap=new HashMap<Integer,Answer>();
			
			httpsession.setAttribute("submittedDetails",hashmap);
			
			httpsession.setAttribute("score",0);
			httpsession.setAttribute("subject",selectedSubject);
		
		}
			
		return modelandview;
		
		
	}
	
	
	
	
		

}

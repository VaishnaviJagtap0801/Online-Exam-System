package com.linkcode.online.exams.controller;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.linkcode.online.exams.entity.Answer;
import com.linkcode.online.exams.entity.Questions;

@Controller
public class QuestionController {
	

	
	@RequestMapping("saveResponse")
	public void saveResponse(Answer answer,HttpServletRequest request ) {
		
		//System.out.println(answer);
		
		HttpSession httpsession=request.getSession();
		List<Questions> listofquestions=(List<Questions>) httpsession.getAttribute("allquestions");

		Questions question=listofquestions.get((int) httpsession.getAttribute("qno"));
		
		String originalAnswer=question.getAnswer();
		
		System.out.println(originalAnswer);
	
		answer.setOriginalAnswer(originalAnswer);
		
		HashMap<Integer,Answer> hashmap=(HashMap<Integer, Answer>) httpsession.getAttribute("submittedDetails");
		
		hashmap.put(answer.qno, answer);
		System.out.println(httpsession.getAttribute("submittedDetails"));
		
		
		
	}
		
		
	
	
	
	@RequestMapping("next")
	public ModelAndView next(HttpServletRequest request) {
		
		ModelAndView modelAndView=new ModelAndView();
		
		modelAndView.setViewName("questions");
		
		HttpSession httpsession=request.getSession();
		
		List<Questions> listofquestions = (List<Questions>) httpsession.getAttribute("allquestions");
		
		if((int)httpsession.getAttribute("qno")<=listofquestions.size()-2)
		{
			httpsession.setAttribute("qno",(int)httpsession.getAttribute("qno")+1);
			
			Questions question=listofquestions.get((int)httpsession.getAttribute("qno"));
			
			
			int qno=question.getQno();
        	HashMap<Integer,Answer> hashmap=(HashMap<Integer, Answer>) httpsession.getAttribute("submittedDetails");
            
            Answer answer=hashmap.get(qno);
            
            String previousAnswer="";
            
            if(answer!=null)
            {
            	previousAnswer=answer.getSubmittedAnswer();
            }
            
            modelAndView.setViewName("questions");
	        modelAndView.addObject("question", question);
	        modelAndView.addObject("previousAnswer", previousAnswer);
	        
		}
		else
		{
		
			modelAndView.addObject("question",listofquestions.get(listofquestions.size()-1));
			modelAndView.addObject("message","This is last question");
			
		}
		return modelAndView;
		
		
	}
	
	
	@RequestMapping("previous")
	public ModelAndView previous(HttpServletRequest request) {
	    ModelAndView modelAndView = new ModelAndView();

	    HttpSession httpsession = request.getSession();
	    List<Questions> listOfQuestions = (List<Questions>) httpsession.getAttribute("allquestions");
	    int currentQno = (int) httpsession.getAttribute("qno");

	    if (currentQno > 0) {
	        int newQno = currentQno - 1;
	        httpsession.setAttribute("qno", newQno);

	        Questions question = listOfQuestions.get(newQno);
            
	        
	        int qno=question.getQno();
        	HashMap<Integer,Answer> hashmap=(HashMap<Integer, Answer>) httpsession.getAttribute("submittedDetails");
            
            Answer answer=hashmap.get(qno);
            
            String previousAnswer="";
            
            if(answer!=null)
            {
            	previousAnswer=answer.getSubmittedAnswer();
            }
            
            modelAndView.setViewName("questions");
	        modelAndView.addObject("question", question);
	        modelAndView.addObject("previousAnswer", previousAnswer);
	        
	        
	    } 
	    
	    else {
	        modelAndView.setViewName("questions");
	        modelAndView.addObject("question", listOfQuestions.get(0));
	        modelAndView.addObject("message", "This is the first question");
	    }

	    return modelAndView;
	}
	
	@RequestMapping("endexam")
	public ModelAndView endexam(HttpServletRequest request) {
		
		HttpSession httpsession=request.getSession();
		
		HashMap<Integer,Answer> hashmap=(HashMap<Integer, Answer>) httpsession.getAttribute("submittedDetails");
		
		Collection<Answer> collection=hashmap.values();
		 
		for (Answer answer : collection) {
			
			if(answer.originalAnswer.equals(answer.submittedAnswer)) {
				
				 httpsession.setAttribute("score",(int)httpsession.getAttribute("score")+1);
				 
				 
				 
			}
		}
		ModelAndView modelAndView=new ModelAndView();
		 
		modelAndView.setViewName("score");
		
		modelAndView.addObject("score",httpsession.getAttribute("score") );
		 
		modelAndView.addObject("allanswers",collection ); 
		return modelAndView;
		
		
		
		
		
	}
	
	

	

}

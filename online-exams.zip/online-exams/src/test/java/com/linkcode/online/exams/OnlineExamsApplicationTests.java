package com.linkcode.online.exams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineExamsApplicationTests {

	@Test
	void contextLoads() {
	}

}
